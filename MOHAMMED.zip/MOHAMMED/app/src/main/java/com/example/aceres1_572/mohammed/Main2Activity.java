package com.example.aceres1_572.mohammed;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main2Activity extends AppCompatActivity {
 Button btng,btnsh,btnw,btnkh,btnr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btng=findViewById(R.id.btn1);
        btnsh=findViewById(R.id.btn2);
        btnw=findViewById(R.id.btn3);
        btnkh=findViewById(R.id.btn4);
        btnr=findViewById(R.id.btn5);

        btng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Main2Activity.this,BTNG.class);
                startActivity(intent);
            }
        });

        btnsh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        btnw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Main2Activity.this,BTNW.class);
                startActivity(intent);

            }
        });


        btnkh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });


        btnr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });



    }
}
