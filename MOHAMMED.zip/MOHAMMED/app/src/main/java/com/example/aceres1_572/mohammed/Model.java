package com.example.aceres1_572.mohammed;

public class Model {
    String id, name, adres, face, web, Prfilepic;

    public Model(String id, String name, String adres, String face,String web,String Prfilepic) {
        this.id = id;
        this.name = name;
        this.adres = adres;
        this.face = face;
        this.web=web;
        this.Prfilepic=Prfilepic;
    }

    public Model() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAdres() {
        return adres;
    }

    public void setAdres(String adres) {
        this.adres = adres;
    }

    public String getFace() {
        return face;
    }

    public void setFace(String face) {
        this.face = face;
    }

    public String getWeb() {
        return web;
    }

    public void setWeb(String web) {
        this.web = web;
    }

    public String getPrfilepic() {
        return Prfilepic;
    }

    public void setPrfilepic(String prfilepic) {
        Prfilepic = prfilepic;
    }


}
