package com.example.aceres1_572.mohammed;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class BTNW extends AppCompatActivity {
       Button btnaddd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_btnw);

        btnaddd=findViewById(R.id.btnAddd);
        btnaddd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(BTNW.this,AddButton.class);
                startActivity(intent);
            }
        });

    }
}
