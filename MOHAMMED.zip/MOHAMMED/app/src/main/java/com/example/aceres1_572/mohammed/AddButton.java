package com.example.aceres1_572.mohammed;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class AddButton extends AppCompatActivity {

    private int Gallery_intent=2;
    private EditText name,adres,face,web;
    private Button addBtn;
    private ImageButton imageButton;
    private DatabaseReference reference;
    private StorageReference imagePathe=null,storage=null;


    private Model model;
    private String ImageLocation;

    private RecyclerView recyclerView;
    private ArrayList<Model> list;
    private Adapterr adapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_button);

        reference=FirebaseDatabase.getInstance().getReference("DataBase").child("Users");
        model = new Model();

        storage=FirebaseStorage.getInstance().getReference();
        name=(EditText)findViewById(R.id.editText);
        adres=(EditText)findViewById(R.id.editText2);
        face=(EditText)findViewById(R.id.editText3);
        web=(EditText)findViewById(R.id.editText4);
        addBtn=findViewById(R.id.button);
        imageButton=findViewById(R.id.imageButton);


        recyclerView=(RecyclerView)findViewById(R.id.rView);
//       recyclerView.setHasFixedSize(true);
     //  recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list=new ArrayList <Model>();


        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()){
                    Model p=dataSnapshot1.getValue(Model.class);
                  //  p.setPrfilepic(dataSnapshot1.getValue(Model.class).Prfilepic);
                    list.add(p);
                }
                adapter=new Adapterr(AddButton.this,list);

//                recyclerView.setAdapter(adapter);

            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(AddButton.this, "هنالك خطأ.......", Toast.LENGTH_SHORT).show();
            }
        });


        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!TextUtils.isEmpty(name.getText().toString())){
                    String id=reference.push().getKey();
                    Model model=new Model(id,name.getText().toString(),adres.getText().toString(),face.getText().toString(),web.getText().toString(),ImageLocation);
                    reference.child(id).setValue(model);
                    Toast.makeText(AddButton.this, "تمت عملية الاضافة بنجاح", Toast.LENGTH_SHORT).show();
                }else {

                    Toast.makeText(AddButton.this, "برجاء إدخال البيانات كاملا", Toast.LENGTH_SHORT).show();
                }
            }
        });

        }

    public void btnimageAdd(View view) {
        Intent intent=new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");

        startActivityForResult(intent,2);

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==2 && resultCode==RESULT_OK) {
            Uri uri = data.getData();
           //  imageButton.setImageURI(uri);
            //imagePathe =FirebaseStorage.getInstance().getReference().child("profile").child(uri.getLastPathSegment());
            imagePathe =FirebaseStorage.getInstance().getReference().child("profile");

            Picasso.with(this).load(uri).into(imageButton);

            StorageReference fileRef =storage.child(System.currentTimeMillis()+"."+getFileExtention(uri));

            fileRef.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                    String id=reference.push().getKey();
                    Model model=new Model(id,name.getText().toString(),adres.getText().toString(),face.getText().toString(),web.getText().toString(),taskSnapshot.getStorage().getDownloadUrl().toString());
                    reference.child(id).setValue(model);
                    Toast.makeText(AddButton.this, "تم تحميل الصورة بنجاح", Toast.LENGTH_LONG).show();


                }
            })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {

                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {

                        }
                    });

        }

    }

    private String getFileExtention(Uri uri) {
        ContentResolver cR=getContentResolver();
        MimeTypeMap mime=MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));

    }


}
