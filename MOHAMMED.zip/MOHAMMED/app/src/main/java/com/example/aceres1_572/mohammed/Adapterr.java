package com.example.aceres1_572.mohammed;
import android.content.Context;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;


import com.squareup.picasso.Picasso;

import java.util.ArrayList;
public class Adapterr extends RecyclerView.Adapter<Adapterr.MyViewHolder> {

    Context context;
    ArrayList<Model> profiles;

    public Adapterr(Context c, ArrayList<Model> p){
        context=c;
        profiles=p;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.cardview,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.ename.setText(profiles.get(position).getName());
        holder.eadres.setText(profiles.get(position).getAdres());
        holder.eface.setText(profiles.get(position).getFace());
        holder.eweb.setText(profiles.get(position).getWeb());
        Picasso.with(context).load(profiles.get(position).getPrfilepic()).fit().centerCrop().into(holder.profilePic);


    }

    @Override
    public int getItemCount()
    {
        return profiles.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{
        TextView ename,eadres,eface,eweb;
        ImageView profilePic;


        public MyViewHolder(View itemView) {
            super(itemView);
            ename=(TextView) itemView.findViewById(R.id.ename);
            eadres=(TextView) itemView.findViewById(R.id.eadres);
            eface=(TextView) itemView.findViewById(R.id.eface);
            eweb=(TextView) itemView.findViewById(R.id.eweb);
            profilePic=(ImageView) itemView.findViewById(R.id.proFilePic);

        }

    }
}
